java -jar Mllib.jar $1

